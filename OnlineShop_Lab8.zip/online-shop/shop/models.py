import uuid
from decimal import Decimal

from django.db import models
from django.utils import timezone


class Product(models.Model):
    name = models.CharField("Название", max_length=120)
    description = models.TextField("Описание", blank=True)
    price = models.DecimalField("Цена, ₸", max_digits=10, decimal_places=2)
    stock = models.PositiveIntegerField("Остаток", default=0)
    icon = models.CharField("Иконка", max_length=8, default="📦")
    is_active = models.BooleanField("Активен", default=True)

    class Meta:
        ordering = ["id"]
        verbose_name = "Товар"
        verbose_name_plural = "Товары"

    def __str__(self):
        return self.name


class Order(models.Model):
    class Status(models.TextChoices):
        PENDING = "pending", "Ожидает оплаты"
        PAID = "paid", "Оплачен"
        ASSEMBLING = "assembling", "На сборке"
        PACKED = "packed", "Упакован"
        SHIPPING = "shipping", "Передан курьеру"
        DELIVERED = "delivered", "Доставлен"
        CANCELLED = "cancelled", "Отменён"

    class Delivery(models.TextChoices):
        COURIER = "courier", "Курьером"
        PICKUP = "pickup", "Самовывоз"

    public_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    customer_name = models.CharField(max_length=100)
    phone = models.CharField(max_length=20)
    email = models.EmailField(blank=True)
    delivery = models.CharField(max_length=16, choices=Delivery.choices)
    address = models.CharField(max_length=250, blank=True)
    pickup_point = models.CharField(max_length=120, blank=True)
    consent_at = models.DateTimeField(default=timezone.now)
    status = models.CharField(max_length=12, choices=Status.choices, default=Status.PENDING)
    total = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal("0.00"))
    created_at = models.DateTimeField(auto_now_add=True)
    paid_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]
        verbose_name = "Заказ"
        verbose_name_plural = "Заказы"

    def __str__(self):
        return f"Заказ #{self.id} — {self.get_status_display()}"


class OrderItem(models.Model):
    order = models.ForeignKey(Order, related_name="items", on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.PROTECT)
    title = models.CharField(max_length=120)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    quantity = models.PositiveIntegerField()

    @property
    def subtotal(self):
        return self.price * self.quantity

    class Meta:
        verbose_name = "Позиция заказа"
        verbose_name_plural = "Позиции заказа"
