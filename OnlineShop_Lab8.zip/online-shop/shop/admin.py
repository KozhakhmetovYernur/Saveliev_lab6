from django.contrib import admin

from .models import Order, OrderItem, Product


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ("name", "price", "stock", "is_active")
    list_filter = ("is_active",)
    search_fields = ("name",)


class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0
    readonly_fields = ("product", "title", "price", "quantity")
    can_delete = False


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ("id", "customer_name", "status", "total", "delivery", "created_at")
    list_filter = ("status", "delivery", "created_at")
    search_fields = ("customer_name", "phone")
    readonly_fields = ("public_id", "total", "paid_at", "created_at", "consent_at")
    inlines = [OrderItemInline]
