from django.core.management.base import BaseCommand

from shop.services import cancel_expired_orders


class Command(BaseCommand):
    help = "Отменить неоплаченные заказы старше 15 минут"

    def handle(self, *args, **kwargs):
        count = cancel_expired_orders()
        self.stdout.write(self.style.SUCCESS(f"Отменено заказов: {count}"))
