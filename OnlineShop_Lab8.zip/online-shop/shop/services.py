"""Бизнес-правила корзины и заказа. Валюту считаем в тенге (₸)."""

from datetime import timedelta
from decimal import Decimal

from django.db import transaction
from django.db.models import F
from django.utils import timezone

from .models import Order, OrderItem, Product

CART_KEY = "online_shop_cart"
PAYMENT_TIMEOUT = timedelta(minutes=15)


class CheckoutError(Exception):
    """Понятная пользователю ошибка оформления/оплаты."""


def cart_dict(request):
    """Вернуть корзину из сессии: {id_товара: количество}."""
    return request.session.get(CART_KEY, {})


def cart_lines(request):
    """Получить актуальные товары и итог; БП-01, БП-02."""
    stored = cart_dict(request)
    products = {str(p.pk): p for p in Product.objects.filter(pk__in=stored.keys(), is_active=True)}
    lines = []
    total = Decimal("0.00")
    for key, value in stored.items():
        product = products.get(key)
        if product is None:
            continue
        quantity = max(1, int(value))
        subtotal = product.price * quantity
        lines.append({"product": product, "quantity": quantity, "subtotal": subtotal})
        total += subtotal
    return lines, total


def add_to_cart(request, product_id, quantity):
    """Добавить товар в корзину, не превышая остаток (БП-01)."""
    product = Product.objects.get(pk=product_id, is_active=True)
    stored = cart_dict(request).copy()
    if not 1 <= quantity <= 99:
        raise CheckoutError("Укажите количество от 1 до 99.")
    updated_quantity = int(stored.get(str(product_id), 0)) + quantity
    if updated_quantity > 99 or updated_quantity > product.stock:
        raise CheckoutError("На складе недостаточно товара.")
    stored[str(product_id)] = updated_quantity
    request.session[CART_KEY] = stored
    request.session.modified = True


def set_cart_quantity(request, product_id, quantity):
    """Изменить количество или убрать товар из корзины (БП-01)."""
    stored = cart_dict(request).copy()
    if quantity <= 0:
        stored.pop(str(product_id), None)
    else:
        product = Product.objects.get(pk=product_id, is_active=True)
        if quantity > 99 or quantity > product.stock:
            raise CheckoutError("Указанное количество недоступно.")
        stored[str(product_id)] = quantity
    request.session[CART_KEY] = stored
    request.session.modified = True


@transaction.atomic
def create_order(request, data):
    """Создать ожидающий оплаты заказ из корзины (БП-01–БП-03)."""
    lines, _ = cart_lines(request)
    if not lines:
        raise CheckoutError("Корзина пуста.")
    # Повторная проверка наличия при оформлении; цены берём с сервера.
    for line in lines:
        if line["quantity"] > line["product"].stock:
            raise CheckoutError(f"Товара «{line['product'].name}» больше нет в нужном количестве.")
    order = Order.objects.create(
        customer_name=data["customer_name"],
        phone=data["phone"],
        email=data.get("email", ""),
        delivery=data["delivery"],
        address=data.get("address", "") if data["delivery"] == Order.Delivery.COURIER else "",
        pickup_point=(
            data.get("pickup_point", "") if data["delivery"] == Order.Delivery.PICKUP else ""
        ),
        consent_at=timezone.now(),
    )
    total = Decimal("0.00")
    for line in lines:
        product = line["product"]
        item = OrderItem.objects.create(
            order=order,
            product=product,
            title=product.name,
            price=product.price,
            quantity=line["quantity"],
        )
        total += item.subtotal
    order.total = total
    order.save(update_fields=["total"])
    request.session[CART_KEY] = {}
    request.session.modified = True
    return order


@transaction.atomic
def confirm_demo_payment(order_public_id):
    """Учебное подтверждение платежа, без реальных банковских реквизитов (БП-04–БП-06)."""
    order = Order.objects.select_for_update().get(public_id=order_public_id)
    if order.status != Order.Status.PENDING:
        raise CheckoutError("Оплатить можно только заказ со статусом «Ожидает оплаты».")
    if timezone.now() - order.created_at >= PAYMENT_TIMEOUT:
        raise CheckoutError("На оплату было 15 минут. Заказ отменён.")
    # Условное атомарное уменьшение остатка защищает от двойной продажи.
    for item in order.items.select_related("product").all():
        changed = Product.objects.filter(
            pk=item.product_id, stock__gte=item.quantity, is_active=True
        ).update(stock=F("stock") - item.quantity)
        if changed != 1:
            raise CheckoutError(f"Товара «{item.title}» недостаточно. Оплата не выполнена.")
    order.status = Order.Status.PAID
    order.paid_at = timezone.now()
    order.save(update_fields=["status", "paid_at"])
    return order


def cancel_expired_orders():
    """Отменить просроченные неоплаченные заказы (БП-05)."""
    threshold = timezone.now() - PAYMENT_TIMEOUT
    return Order.objects.filter(status=Order.Status.PENDING, created_at__lte=threshold).update(
        status=Order.Status.CANCELLED
    )
