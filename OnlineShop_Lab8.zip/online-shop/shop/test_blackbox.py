from datetime import timedelta
from unittest.mock import patch

from django.contrib.messages.storage.fallback import FallbackStorage
from django.contrib.sessions.backends.db import SessionStore
from django.test import RequestFactory, TestCase
from django.utils import timezone

from . import services as s
from . import views
from .forms import CheckoutForm
from .models import Order, Product


class Scenario(TestCase):
    def setUp(self):
        self.product = Product.objects.create(name="Кабель", price=1000, stock=200)
        self.request = RequestFactory().post("/")
        self.request.session = SessionStore()
        self.request._messages = FallbackStorage(self.request)
        self.now = timezone.now()
        self.clock = self.enterContext(patch("shop.services.timezone.now", return_value=self.now))
        self.data = dict(
            customer_name="Савелий",
            phone="+77000000001",
            delivery="courier",
            address="Дом 1",
            consent=True,
        )

    def order(self):
        self.request.session[s.CART_KEY] = {str(self.product.pk): 1}
        return s.create_order(self.request, self.data)


class BlackBox(Scenario):
    def test_phone(self):
        """Формат телефона: 7/8 и 15/16 цифр."""
        for size, valid in [(7, False), (8, True), (15, True), (16, False)]:
            with self.subTest(size=size):
                self.assertEqual(CheckoutForm({**self.data, "phone": "7" * size}).is_valid(), valid)

    def test_quantity(self):
        """Количество 0/1 и 99/100."""
        for q, valid in [(0, False), (1, True), (99, True), (100, False)]:
            self.request.session[s.CART_KEY] = {}
            with self.subTest(q=q):
                if valid:
                    s.add_to_cart(self.request, self.product.pk, q)
                else:
                    with self.assertRaises(s.CheckoutError):
                        s.add_to_cart(self.request, self.product.pk, q)

    def test_total_limit(self):
        """Итог после двух добавлений не превышает 99."""
        s.add_to_cart(self.request, self.product.pk, 99)
        with self.assertRaises(s.CheckoutError):
            s.add_to_cart(self.request, self.product.pk, 1)

    def test_delivery(self):
        """Курьер требует адрес, самовывоз — пункт; согласие обязательно."""
        for delivery, address, pickup, consent, valid in [
            ("courier", "", "", True, False),
            ("courier", "Дом", "", True, True),
            ("pickup", "", "Пункт", True, True),
            ("pickup", "", "", True, False),
            ("courier", "Дом", "", False, False),
        ]:
            with self.subTest(delivery=delivery, address=address, consent=consent):
                self.assertEqual(
                    CheckoutForm(
                        {
                            **self.data,
                            "delivery": delivery,
                            "address": address,
                            "pickup_point": pickup,
                            "consent": consent,
                        }
                    ).is_valid(),
                    valid,
                )

    def test_deadline(self):
        """Движение часов через границу 15 минут."""
        order = self.order()
        self.clock.return_value = order.created_at + timedelta(seconds=899)
        self.assertEqual(s.cancel_expired_orders(), 0)
        self.clock.return_value = order.created_at + timedelta(seconds=900)
        self.assertEqual(s.cancel_expired_orders(), 1)
        order.refresh_from_db()
        self.assertEqual(order.status, "cancelled")

    def test_states(self):
        """Только ожидающий заказ допускает переход в paid."""
        for state in Order.Status.values:
            o = self.order()
            o.status = state
            o.save()
            with self.subTest(state=state):
                if state == "pending":
                    self.assertEqual(s.confirm_demo_payment(o.public_id).status, "paid")
                else:
                    with self.assertRaises(s.CheckoutError):
                        s.confirm_demo_payment(o.public_id)

    def test_stock(self):
        """Недостаточный остаток отклоняет оплату с откатом."""
        o = self.order()
        Product.objects.filter(pk=self.product.pk).update(stock=0)
        with self.assertRaises(s.CheckoutError):
            s.confirm_demo_payment(o.public_id)
        o.refresh_from_db()
        self.assertEqual(o.status, "pending")

    def test_expired(self):
        """При точном дедлайне оплатить нельзя."""
        o = self.order()
        self.clock.return_value = o.created_at + timedelta(minutes=15)
        with self.assertRaises(s.CheckoutError):
            s.confirm_demo_payment(o.public_id)


class WhiteBox(Scenario):
    def test_cart_branches(self):
        """Удаление, допустимая замена и превышение остатка."""
        s.set_cart_quantity(self.request, self.product.pk, 2)
        s.set_cart_quantity(self.request, self.product.pk, 0)
        with self.assertRaises(s.CheckoutError):
            s.set_cart_quantity(self.request, self.product.pk, 100)
        Product.objects.filter(pk=self.product.pk).update(stock=0)
        with self.assertRaises(s.CheckoutError):
            s.add_to_cart(self.request, self.product.pk, 1)
        self.request.session[s.CART_KEY] = {}
        with self.assertRaises(s.CheckoutError):
            s.create_order(self.request, self.data)
        self.request.session[s.CART_KEY] = {str(self.product.pk): 1}
        with self.assertRaises(s.CheckoutError):
            s.create_order(self.request, self.data)


class TopDown(Scenario):
    def test_exception(self):
        """CheckoutError отображается после POST; сервис вызван один раз."""
        order = self.order()
        with patch(
            "shop.views.confirm_demo_payment", side_effect=s.CheckoutError("Ошибка оплаты")
        ) as stub:
            response = views.payment_confirm(self.request, order.public_id)
            self.assertEqual(response.status_code, 302)
            stub.assert_called_once_with(order.public_id)

    def test_missing(self):
        """Отсутствующий заказ даёт Http404."""
        from django.http import Http404

        with patch("shop.views.confirm_demo_payment", side_effect=Order.DoesNotExist) as stub:
            with self.assertRaises(Http404):
                views.payment_confirm(self.request, "missing")
            stub.assert_called_once()
