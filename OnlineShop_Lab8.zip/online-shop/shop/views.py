from django.contrib import messages
from django.http import Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from .forms import CheckoutForm
from .models import Order, Product
from .services import (
    CheckoutError,
    add_to_cart,
    cancel_expired_orders,
    cart_lines,
    confirm_demo_payment,
    create_order,
    set_cart_quantity,
)


def catalog(request):
    search = request.GET.get("q", "").strip()
    products = Product.objects.filter(is_active=True)
    if search:
        products = products.filter(name__icontains=search)
    return render(request, "shop/catalog.html", {"products": products, "search": search})


def product_detail(request, pk):
    product = get_object_or_404(Product, pk=pk, is_active=True)
    return render(request, "shop/product.html", {"product": product})


@require_POST
def cart_add(request, pk):
    try:
        quantity = int(request.POST.get("quantity", "1"))
        add_to_cart(request, pk, quantity)
        messages.success(request, "Товар добавлен в корзину.")
    except (ValueError, CheckoutError) as exc:
        messages.error(
            request, str(exc) if isinstance(exc, CheckoutError) else "Неверное количество."
        )
    except Product.DoesNotExist:
        raise Http404("Товар не найден") from None
    return redirect("cart")


def cart_view(request):
    lines, total = cart_lines(request)
    return render(request, "shop/cart.html", {"lines": lines, "total": total})


@require_POST
def cart_update(request, pk):
    try:
        set_cart_quantity(request, pk, int(request.POST.get("quantity", "0")))
    except (ValueError, CheckoutError) as exc:
        messages.error(
            request, str(exc) if isinstance(exc, CheckoutError) else "Неверное количество."
        )
    except Product.DoesNotExist:
        raise Http404("Товар не найден") from None
    return redirect("cart")


def checkout(request):
    lines, total = cart_lines(request)
    if not lines:
        messages.error(request, "Сначала добавьте товар в корзину.")
        return redirect("cart")
    form = CheckoutForm(request.POST or None, initial={"delivery": "courier"})
    if request.method == "POST" and form.is_valid():
        try:
            order = create_order(request, form.cleaned_data)
            return redirect("payment", public_id=order.public_id)
        except CheckoutError as exc:
            messages.error(request, str(exc))
    return render(request, "shop/checkout.html", {"form": form, "lines": lines, "total": total})


def payment(request, public_id):
    order = get_object_or_404(Order, public_id=public_id)
    return render(request, "shop/payment.html", {"order": order})


@require_POST
def payment_confirm(request, public_id):
    cancel_expired_orders()
    try:
        confirm_demo_payment(public_id)
        messages.success(request, "Учебная оплата подтверждена. Деньги не списывались.")
    except Order.DoesNotExist:
        raise Http404("Заказ не найден") from None
    except CheckoutError as exc:
        messages.error(request, str(exc))
    return redirect("order_status", public_id=public_id)


def order_status(request, public_id):
    order = get_object_or_404(Order.objects.prefetch_related("items"), public_id=public_id)
    return render(request, "shop/order.html", {"order": order})
