# Initial migration for the university demonstration project.
import uuid
from decimal import Decimal

from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone


class Migration(migrations.Migration):
    initial = True
    dependencies = []
    operations = [
        migrations.CreateModel(
            name="Product",
            fields=[
                ("id", models.BigAutoField(primary_key=True, serialize=False)),
                ("name", models.CharField(max_length=120, verbose_name="Название")),
                ("description", models.TextField(blank=True, verbose_name="Описание")),
                ("price", models.DecimalField(decimal_places=2, max_digits=10, verbose_name="Цена, ₸")),
                ("stock", models.PositiveIntegerField(default=0, verbose_name="Остаток")),
                ("icon", models.CharField(default="📦", max_length=8, verbose_name="Иконка")),
                ("is_active", models.BooleanField(default=True, verbose_name="Активен")),
            ],
            options={"verbose_name": "Товар", "verbose_name_plural": "Товары", "ordering": ["id"]},
        ),
        migrations.CreateModel(
            name="Order",
            fields=[
                ("id", models.BigAutoField(primary_key=True, serialize=False)),
                ("public_id", models.UUIDField(default=uuid.uuid4, editable=False, unique=True)),
                ("customer_name", models.CharField(max_length=100)),
                ("phone", models.CharField(max_length=20)),
                ("email", models.EmailField(blank=True, max_length=254)),
                ("delivery", models.CharField(choices=[("courier", "Курьером"), ("pickup", "Самовывоз")], max_length=16)),
                ("address", models.CharField(blank=True, max_length=250)),
                ("pickup_point", models.CharField(blank=True, max_length=120)),
                ("consent_at", models.DateTimeField(default=django.utils.timezone.now)),
                ("status", models.CharField(choices=[("pending", "Ожидает оплаты"), ("paid", "Оплачен"), ("assembling", "На сборке"), ("packed", "Упакован"), ("shipping", "Передан курьеру"), ("delivered", "Доставлен"), ("cancelled", "Отменён")], default="pending", max_length=12)),
                ("total", models.DecimalField(decimal_places=2, default=Decimal("0.00"), max_digits=12)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("paid_at", models.DateTimeField(blank=True, null=True)),
            ],
            options={"verbose_name": "Заказ", "verbose_name_plural": "Заказы", "ordering": ["-created_at"]},
        ),
        migrations.CreateModel(
            name="OrderItem",
            fields=[
                ("id", models.BigAutoField(primary_key=True, serialize=False)),
                ("title", models.CharField(max_length=120)),
                ("price", models.DecimalField(decimal_places=2, max_digits=10)),
                ("quantity", models.PositiveIntegerField()),
                ("order", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="items", to="shop.order")),
                ("product", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, to="shop.product")),
            ],
            options={"verbose_name": "Позиция заказа", "verbose_name_plural": "Позиции заказа"},
        ),
    ]
