from django.urls import path

from . import views

urlpatterns = [
    path("", views.catalog, name="catalog"),
    path("products/<int:pk>/", views.product_detail, name="product_detail"),
    path("cart/", views.cart_view, name="cart"),
    path("cart/add/<int:pk>/", views.cart_add, name="cart_add"),
    path("cart/update/<int:pk>/", views.cart_update, name="cart_update"),
    path("checkout/", views.checkout, name="checkout"),
    path("orders/<uuid:public_id>/payment/", views.payment, name="payment"),
    path("orders/<uuid:public_id>/payment/confirm/", views.payment_confirm, name="payment_confirm"),
    path("orders/<uuid:public_id>/", views.order_status, name="order_status"),
]
