from datetime import timedelta
from decimal import Decimal

from django.core.management import call_command
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from .models import Order, Product
from .services import cancel_expired_orders


class ShopTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.product = Product.objects.create(
            name="Тестовая мышь", price=Decimal("1000.00"), stock=5, icon="🖱️"
        )

    def add_one(self):
        return self.client.post(reverse("cart_add", args=[self.product.pk]), {"quantity": 1})

    def checkout_data(self, **kwargs):
        return {
            "customer_name": "Тестовый Клиент",
            "phone": "+77001234567",
            "email": "test@example.com",
            "delivery": "courier",
            "address": "Астана, тестовая 1",
            "consent": True,
            **kwargs,
        }

    def make_order(self):
        self.add_one()
        response = self.client.post(reverse("checkout"), self.checkout_data())
        self.assertEqual(response.status_code, 302)
        return Order.objects.get()

    def test_catalog_and_search(self):
        self.assertContains(self.client.get(reverse("catalog")), "Тестовая мышь")
        self.assertContains(
            self.client.get(reverse("catalog") + "?q=неттакоготовара"), "Ничего не нашлось"
        )

    def test_product_detail(self):
        self.assertContains(
            self.client.get(reverse("product_detail", args=[self.product.pk])), "1000"
        )

    def test_cart_add_and_total(self):
        self.add_one()
        self.assertContains(self.client.get(reverse("cart")), "1000", html=False)

    def test_cart_quantity_cannot_exceed_stock(self):
        self.client.post(reverse("cart_add", args=[self.product.pk]), {"quantity": 6})
        self.assertEqual(self.client.session.get("online_shop_cart", {}), {})

    def test_cart_requires_post(self):
        response = self.client.get(reverse("cart_add", args=[self.product.pk]))
        self.assertEqual(response.status_code, 405)

    def test_checkout_requires_consent(self):
        self.add_one()
        response = self.client.post(reverse("checkout"), self.checkout_data(consent=False))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(Order.objects.count(), 0)

    def test_checkout_requires_address_for_courier(self):
        self.add_one()
        response = self.client.post(reverse("checkout"), self.checkout_data(address=""))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(Order.objects.count(), 0)

    def test_pickup_without_address(self):
        self.add_one()
        response = self.client.post(
            reverse("checkout"),
            self.checkout_data(delivery="pickup", address="", pickup_point="Пункт 1"),
        )
        self.assertEqual(response.status_code, 302)
        order = Order.objects.get()
        self.assertEqual(order.address, "")
        self.assertEqual(order.pickup_point, "Пункт 1")

    def test_order_snapshots_price_and_clears_cart(self):
        order = self.make_order()
        self.assertEqual(order.total, Decimal("1000.00"))
        self.assertEqual(order.items.get().price, Decimal("1000.00"))
        self.assertEqual(order.status, Order.Status.PENDING)
        self.assertEqual(self.client.session.get("online_shop_cart"), {})

    def test_demo_payment_decrements_stock(self):
        order = self.make_order()
        response = self.client.post(reverse("payment_confirm", args=[order.public_id]))
        self.assertEqual(response.status_code, 302)
        order.refresh_from_db()
        self.product.refresh_from_db()
        self.assertEqual(order.status, Order.Status.PAID)
        self.assertEqual(self.product.stock, 4)

    def test_double_payment_is_blocked(self):
        order = self.make_order()
        url = reverse("payment_confirm", args=[order.public_id])
        self.client.post(url)
        self.client.post(url)
        self.product.refresh_from_db()
        self.assertEqual(self.product.stock, 4)

    def test_payment_out_of_stock_rolls_back(self):
        order = self.make_order()
        Product.objects.filter(pk=self.product.pk).update(stock=0)
        self.client.post(reverse("payment_confirm", args=[order.public_id]))
        order.refresh_from_db()
        self.assertEqual(order.status, Order.Status.PENDING)

    def test_expired_order_is_cancelled(self):
        order = self.make_order()
        Order.objects.filter(pk=order.pk).update(created_at=timezone.now() - timedelta(minutes=16))
        cancel_expired_orders()
        order.refresh_from_db()
        self.assertEqual(order.status, Order.Status.CANCELLED)

    def test_seed_is_idempotent(self):
        call_command("seed_demo", verbosity=0)
        call_command("seed_demo", verbosity=0)
        self.assertEqual(Product.objects.filter(name="USB-C кабель").count(), 1)

    def test_status_page_opens_with_public_token(self):
        order = self.make_order()
        self.assertContains(
            self.client.get(reverse("order_status", args=[order.public_id])), "Ожидает оплаты"
        )
