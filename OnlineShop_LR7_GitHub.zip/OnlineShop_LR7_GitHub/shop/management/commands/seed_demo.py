from decimal import Decimal

from django.core.management.base import BaseCommand

from shop.models import Product


class Command(BaseCommand):
    help = "Добавить демонстрационные товары в каталог (повторный запуск безопасен)"

    def handle(self, *args, **options):
        samples = [
            ("Наушники беспроводные", "Удобные наушники для повседневного использования.", "18990", 16, "🎧"),
            ("Портативная консоль", "Компактная игровая система для дороги и дома.", "84990", 7, "🎮"),
            ("Механическая клавиатура", "Компактная клавиатура с подсветкой.", "27990", 12, "⌨️"),
            ("Умные часы", "Часы с уведомлениями и подсчётом шагов.", "32990", 9, "⌚"),
            ("Беспроводная мышь", "Лёгкая мышь с точным сенсором.", "12990", 22, "🖱️"),
            ("USB-C кабель", "Кабель длиной один метр.", "3990", 35, "🔌"),
        ]
        for name, description, price, stock, icon in samples:
            Product.objects.update_or_create(
                name=name,
                defaults={"description": description, "price": Decimal(price),
                          "stock": stock, "icon": icon, "is_active": True},
            )
        self.stdout.write(self.style.SUCCESS(f"Готово: товаров {len(samples)}"))
