import re

from django import forms

from .models import Order


class CheckoutForm(forms.Form):
    customer_name = forms.CharField(label="Имя и фамилия", max_length=100)
    phone = forms.CharField(label="Телефон", max_length=20)
    email = forms.EmailField(label="Электронная почта", required=False)
    delivery = forms.ChoiceField(
        label="Способ получения", choices=Order.Delivery.choices, widget=forms.RadioSelect
    )
    address = forms.CharField(label="Адрес доставки", required=False, max_length=250)
    pickup_point = forms.CharField(label="Пункт самовывоза", required=False, max_length=120)
    consent = forms.BooleanField(
        label="Согласен на обработку данных для оформления и получения заказа"
    )

    def clean_phone(self):
        phone = self.cleaned_data["phone"].replace(" ", "").replace("-", "")
        if not re.fullmatch(r"\+?\d{8,15}", phone):
            raise forms.ValidationError("Введите номер: от 8 до 15 цифр, можно с +.")
        return phone

    def clean(self):
        data = super().clean()
        if data.get("delivery") == Order.Delivery.COURIER and not data.get("address", "").strip():
            self.add_error("address", "Укажите адрес доставки.")
        if data.get("delivery") == Order.Delivery.PICKUP and not data.get("pickup_point", "").strip():
            self.add_error("pickup_point", "Укажите пункт самовывоза.")
        return data
