from django.test import TestCase
from django.urls import reverse


class OrderTests(TestCase):
    def setUp(self):
        self.client.post(reverse("add_to_cart", args=[1]))

    def test_delivery_requires_address(self):
        form = {
            "customer_name": "Тест", "phone": "+77001234567",
            "delivery_method": "delivery", "address": "", "consent": "on",
        }
        response = self.client.post(reverse("checkout"), form)
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Для доставки укажите адрес")

    def test_creates_order_with_payment_pending(self):
        response = self.client.post(
            reverse("checkout"),
            {
                "customer_name": "Тест", "phone": "+77001234567",
                "delivery_method": "pickup", "consent": "on",
            },
        )
        self.assertEqual(response.status_code, 302)
        orders = self.client.session["orders"]
        self.assertEqual(len(orders), 1)
        order = list(orders.values())[0]
        self.assertEqual(order["status"], "Ожидает оплаты")
        self.assertEqual(order["total"], 29990)
        self.assertEqual(self.client.session["cart"], {})

    def test_no_consent_no_order(self):
        self.client.post(
            reverse("checkout"),
            {
                "customer_name": "Тест", "phone": "+77001234567",
                "delivery_method": "pickup",
            },
        )
        self.assertFalse(self.client.session.get("orders"))
