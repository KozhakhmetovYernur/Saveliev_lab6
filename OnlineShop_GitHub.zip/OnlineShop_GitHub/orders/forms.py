from django import forms


class CheckoutForm(forms.Form):
    customer_name = forms.CharField(label="Имя", max_length=100)
    phone = forms.RegexField(
        label="Телефон", regex=r"^\+?[0-9]{8,15}$",
        error_messages={"invalid": "Введите номер из 8–15 цифр."},
    )
    email = forms.EmailField(label="E-mail", required=False)
    delivery_method = forms.ChoiceField(
        label="Получение заказа",
        choices=[("delivery", "Доставка"), ("pickup", "Самовывоз")],
        widget=forms.RadioSelect,
    )
    address = forms.CharField(label="Адрес доставки", max_length=250, required=False)
    consent = forms.BooleanField(label="Согласен на обработку данных")

    def clean(self):
        """Validate delivery address (BP-03)."""
        data = super().clean()
        delivery = data.get("delivery_method") == "delivery"
        missing_address = not data.get("address", "").strip()
        if delivery and missing_address:
            self.add_error("address", "Для доставки укажите адрес.")
        return data
