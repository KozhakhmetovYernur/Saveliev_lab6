"""Order creation and status transitions for the educational skeleton."""

from uuid import uuid4

from cart.services import get_cart_items, get_total


def create_demo_order(cart, clean_data):
    """Create a JSON-serializable session order after stock checks (BP-01, BP-04)."""
    items = get_cart_items(cart)
    if not items:
        raise ValueError("Корзина пуста")
    for item in items:
        if item["quantity"] > item["product"]["stock"]:
            raise ValueError("Товара недостаточно на складе")
    total = get_total(items)
    return {
        "id": uuid4().hex[:10].upper(),
        "customer_name": clean_data["customer_name"],
        "phone": clean_data["phone"],
        "delivery_method": clean_data["delivery_method"],
        "address": clean_data.get("address", ""),
        "items": [
            {
                "name": item["product"]["name"],
                "price": item["product"]["price"],
                "quantity": item["quantity"],
                "subtotal": item["subtotal"],
            }
            for item in items
        ],
        "total": total,
        "status": "Ожидает оплаты",
    }
