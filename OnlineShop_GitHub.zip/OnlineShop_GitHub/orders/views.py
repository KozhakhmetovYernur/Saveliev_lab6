from django.contrib import messages
from django.http import Http404
from django.shortcuts import redirect, render

from cart.services import get_cart_items, get_total
from .forms import CheckoutForm
from .services import create_demo_order


def checkout(request):
    """Display checkout or create a session-backed order."""
    items = get_cart_items(request.session.get("cart", {}))
    if not items:
        messages.error(request, "Сначала добавьте товар в корзину.")
        return redirect("cart_detail")
    if request.method == "POST":
        form = CheckoutForm(request.POST)
        if form.is_valid():
            try:
                order = create_demo_order(request.session["cart"], form.cleaned_data)
            except ValueError as exc:
                form.add_error(None, str(exc))
            else:
                orders = request.session.get("orders", {})
                orders[order["id"]] = order
                request.session["orders"] = orders
                request.session["cart"] = {}
                return redirect("order_detail", order_id=order["id"])
    else:
        form = CheckoutForm(initial={"delivery_method": "delivery"})
    return render(
        request,
        "orders/checkout.html",
        {"form": form, "items": items, "total": get_total(items)},
    )


def order_detail(request, order_id):
    """Show only an order stored in this browser's session."""
    order = request.session.get("orders", {}).get(order_id)
    if order is None:
        raise Http404("Заказ не найден")
    return render(request, "orders/detail.html", {"order": order})
