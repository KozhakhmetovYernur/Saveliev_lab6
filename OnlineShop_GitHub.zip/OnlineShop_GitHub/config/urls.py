from django.contrib import admin
from django.http import JsonResponse
from django.urls import include, path


def health(request):
    """A simple application health endpoint."""
    return JsonResponse({"status": "ok", "service": "OnlineShop"})


urlpatterns = [
    path("admin/", admin.site.urls),
    path("", include("catalog.urls")),
    path("", include("cart.urls")),
    path("", include("orders.urls")),
    path("", include("payments.urls")),
    path("api/products/", include("catalog.api_urls")),
    path("api/health/", health, name="health"),
]
