# OnlineShop — учебный интернет-магазин

Готовый **GitHub-проект для ЛР №6** «Выбор технологий и подготовка к разработке».
Предметная область: **оформление заказа в интернет-магазине** (ЛР №1–5).

## Что уже работает

- Каталог и карточка товара (экраны Э-01, Э-02).
- Добавление товара в корзину, изменение количества и удаление (Э-03).
- Форма покупателя с валидацией и выбором доставки / самовывоза (Э-04).
- Создание учебного заказа и просмотр статуса (Э-05–Э-07).
- **Тестовая** кнопка «Подтвердить оплату», которая переводит заказ в статус «Оплачен» без реальных платежей.
- JSON API: `GET /api/products/` и `GET /api/health/`.
- Тесты на Django TestCase и автоматическая проверка при push в GitHub Actions.

**Важно:** это учебный *walking skeleton*, а не готовая коммерческая платформа.
Каталог хранится в `catalog/services.py`, корзина и заказы — в сессиях Django.
Платёжный сервис не подключён, реквизиты банковских карт не запрашиваются.
Для промышленного использования нужны модели БД, платёжный шлюз, авторизация,
безопасное хранение данных, обработка ошибок, настройка продакшен-сервера.

## Технологии

Python 3.12+, Django 5.2, SQLite для локальных сессий, HTML/CSS, GitHub Actions,
Ruff. План дальнейшего развития — PostgreSQL и внешний платёжный шлюз.
Решение зафиксировано в [`docs/adr/ADR-001.md`](docs/adr/ADR-001.md).

## Запуск на Windows (PowerShell)

```powershell
py -3.12 -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
```

Если PowerShell запрещает запуск скриптов, активируйте окружение в командной
строке (`.venv\Scripts\activate.bat`) или вызовите `.venv\Scripts\python.exe`
напрямую.

## Запуск на macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
```

Страница: http://127.0.0.1:8000/  
JSON API: http://127.0.0.1:8000/api/products/

## Проверка

```bash
python manage.py check
python manage.py test
ruff check .
ruff format --check .
```

## Публикация в GitHub

1. Создайте пустой репозиторий `OnlineShop-LR6` без авто-README.
2. Откройте терминал в папке проекта (после распаковки ZIP).
3. Выполните команды:

```bash
git init
git add .
git commit -m "chore: initial online shop skeleton"
git branch -M main
git remote add origin https://github.com/USERNAME/OnlineShop-LR6.git
git push -u origin main
```

Замените `USERNAME` своим логином GitHub. Если Git просит авторизацию,
войдите через браузер или используйте настроенный SSH / Git Credential Manager.

Для ЛР №6 при необходимости покажите несколько осмысленных коммитов:
например `docs: add ADR`, `feat: add catalog`, `feat: add checkout`,
`test: cover order flow`. Не создавайте фиктивные коммиты только для числа.

## Структура

```text
OnlineShop_GitHub/
├── .github/workflows/tests.yml   # CI
├── catalog/                      # товары и JSON API
├── cart/                         # корзина
├── orders/                       # оформление и статусы
├── payments/                     # учебная оплата
├── config/                       # конфигурация Django
├── templates/                    # общая страница
├── static/css/                   # простые стили
├── docs/adr/ADR-001.md           # выбор стека
├── docs/architecture.md          # модули и API
├── manage.py
├── requirements.txt
└── pyproject.toml
```

## Соглашения

PEP 8, Ruff, `snake_case` для функций, `PascalCase` для классов,
Conventional Commits. Бизнес-правила размещаются в файлах `services.py`,
а не в HTML-шаблонах. Не добавляйте `.env`, `.venv` и `db.sqlite3` в Git.
