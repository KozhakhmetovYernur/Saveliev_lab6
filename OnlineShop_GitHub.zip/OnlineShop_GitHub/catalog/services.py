"""Demo catalogue and stock verification (business rule BP-01)."""

PRODUCTS = [
    {
        "id": 1, "name": "Смартфон", "price": 29990,
        "stock": 5, "category": "Электроника",
    },
    {"id": 2, "name": "Наушники", "price": 12990, "stock": 8, "category": "Аксессуары"},
    {
        "id": 3, "name": "Умные часы", "price": 19990,
        "stock": 3, "category": "Электроника",
    },
    {
        "id": 4, "name": "Клавиатура", "price": 8990,
        "stock": 0, "category": "Аксессуары",
    },
]


def list_products(query=""):
    """List products filtered by case-insensitive name matching."""
    return [p for p in PRODUCTS if query.lower() in p["name"].lower()]


def get_product(product_id):
    """Find a product by ID or return None."""
    return next((p for p in PRODUCTS if p["id"] == product_id), None)
