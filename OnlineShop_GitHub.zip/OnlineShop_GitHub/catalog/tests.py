from django.test import TestCase
from django.urls import reverse


class CatalogTests(TestCase):
    def test_catalog_screen(self):
        response = self.client.get(reverse("catalog"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Смартфон")

    def test_api_returns_four_products(self):
        response = self.client.get(reverse("products_api"))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.json()["items"]), 4)

    def test_search_returns_filtered_products(self):
        response = self.client.get(reverse("catalog"), {"q": "Наушники"})
        self.assertContains(response, "Наушники")
        self.assertNotContains(response, "Смартфон")
