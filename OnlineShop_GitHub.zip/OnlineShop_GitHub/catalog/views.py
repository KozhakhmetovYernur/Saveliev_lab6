from django.http import Http404, JsonResponse
from django.shortcuts import render

from .services import get_product, list_products


def catalog(request):
    """Render catalogue screen E-01."""
    query = request.GET.get("q", "").strip()
    return render(
        request,
        "catalog/list.html",
        {"products": list_products(query), "query": query},
    )


def product_detail(request, product_id):
    """Render product screen E-02."""
    product = get_product(product_id)
    if product is None:
        raise Http404("Товар не найден")
    return render(request, "catalog/detail.html", {"product": product})


def products_api(request):
    """Return the demo catalogue as JSON."""
    return JsonResponse({"items": list_products()})
