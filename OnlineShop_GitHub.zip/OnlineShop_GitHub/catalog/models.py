"""Catalogue is a static demo; Django Product model is planned for later."""
