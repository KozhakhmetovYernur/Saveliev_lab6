from django.http import Http404
from django.shortcuts import redirect
from django.views.decorators.http import require_POST

from .services import mark_demo_paid


@require_POST
def demo_pay(request, order_id):
    """Demonstrate payment success; no money/card data is processed."""
    orders = request.session.get("orders", {})
    order = orders.get(order_id)
    if order is None:
        raise Http404("Заказ не найден")
    try:
        orders[order_id] = mark_demo_paid(order)
    except ValueError:
        pass
    request.session["orders"] = orders
    return redirect("order_detail", order_id=order_id)
