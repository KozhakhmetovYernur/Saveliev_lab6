"""Demo-only payment stub; no bank card information is stored."""
