"""Payment status simulation, NOT a real payment processor (BP-04)."""


def mark_demo_paid(order):
    """Return a copy of an order marked paid for local demonstrations."""
    if order["status"] != "Ожидает оплаты":
        raise ValueError("Повторное подтверждение оплаты невозможно")
    return {**order, "status": "Оплачен (демо)"}
