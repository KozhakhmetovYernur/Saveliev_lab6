from django.urls import path

from .views import demo_pay

urlpatterns = [
    path("orders/<str:order_id>/demo-pay/", demo_pay, name="demo_pay"),
]
