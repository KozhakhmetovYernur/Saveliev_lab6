from django.test import TestCase
from django.urls import reverse


class DemoPaymentTests(TestCase):
    def test_demo_payment_marks_order_paid(self):
        self.client.post(reverse("add_to_cart", args=[2]))
        self.client.post(
            reverse("checkout"),
            {
                "customer_name": "Клиент", "phone": "+77001234567",
                "delivery_method": "pickup", "consent": "on",
            },
        )
        order_id = next(iter(self.client.session["orders"]))
        response = self.client.post(reverse("demo_pay", args=[order_id]))
        self.assertEqual(response.status_code, 302)
        self.assertEqual(
            self.client.session["orders"][order_id]["status"], "Оплачен (демо)"
        )

    def test_payment_requires_post(self):
        response = self.client.get(reverse("demo_pay", args=["any"]))
        self.assertEqual(response.status_code, 405)
