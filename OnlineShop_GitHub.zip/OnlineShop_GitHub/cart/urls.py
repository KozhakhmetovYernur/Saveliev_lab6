from django.urls import path

from .views import add_to_cart, cart_detail, update_cart

urlpatterns = [
    path("cart/", cart_detail, name="cart_detail"),
    path("cart/add/<int:product_id>/", add_to_cart, name="add_to_cart"),
    path("cart/update/<int:product_id>/", update_cart, name="update_cart"),
]
