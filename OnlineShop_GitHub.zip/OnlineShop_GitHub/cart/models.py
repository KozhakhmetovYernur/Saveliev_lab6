"""Cart is stored in Django session in this educational skeleton."""
