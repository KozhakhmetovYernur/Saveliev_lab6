from django.test import TestCase
from django.urls import reverse


class CartTests(TestCase):
    def test_add_to_cart(self):
        self.client.post(reverse("add_to_cart", args=[1]))
        response = self.client.get(reverse("cart_detail"))
        self.assertContains(response, "Смартфон")
        self.assertContains(response, "29990")

    def test_out_of_stock_cannot_be_added(self):
        self.client.post(reverse("add_to_cart", args=[4]))
        self.assertNotIn("4", self.client.session.get("cart", {}))

    def test_quantity_cannot_exceed_stock(self):
        self.client.post(reverse("add_to_cart", args=[1]))
        self.client.post(reverse("update_cart", args=[1]), {"quantity": 100})
        self.assertEqual(self.client.session["cart"]["1"], 1)
