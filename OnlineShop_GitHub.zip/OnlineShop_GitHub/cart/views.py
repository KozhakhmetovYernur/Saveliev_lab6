from django.contrib import messages
from django.http import Http404
from django.shortcuts import redirect, render
from django.views.decorators.http import require_POST

from catalog.services import get_product
from .services import get_cart_items, get_total


def cart_detail(request):
    """Render the cart and its total (E-03)."""
    items = get_cart_items(request.session.get("cart", {}))
    return render(
        request, "cart/detail.html", {"items": items, "total": get_total(items)}
    )


@require_POST
def add_to_cart(request, product_id):
    """Add one product, not exceeding stock (BP-01)."""
    product = get_product(product_id)
    if product is None:
        raise Http404("Товар не найден")
    cart = request.session.get("cart", {})
    key = str(product_id)
    if int(cart.get(key, 0)) >= product["stock"]:
        messages.error(request, "Товара больше нет в наличии в нужном количестве.")
    else:
        cart[key] = int(cart.get(key, 0)) + 1
        request.session["cart"] = cart
        messages.success(request, "Товар добавлен в корзину.")
    return redirect("cart_detail")


@require_POST
def update_cart(request, product_id):
    """Update cart quantity (set 0 to remove an item)."""
    product = get_product(product_id)
    if product is None:
        raise Http404("Товар не найден")
    try:
        quantity = int(request.POST.get("quantity", ""))
    except ValueError:
        quantity = -1
    if quantity < 0 or quantity > product["stock"]:
        messages.error(request, "Укажите доступное количество товара.")
        return redirect("cart_detail")
    cart = request.session.get("cart", {})
    if quantity == 0:
        cart.pop(str(product_id), None)
    else:
        cart[str(product_id)] = quantity
    request.session["cart"] = cart
    return redirect("cart_detail")
