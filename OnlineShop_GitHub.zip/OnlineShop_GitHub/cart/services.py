"""Session cart services: business rules BP-01 and BP-02."""

from catalog.services import get_product


def get_cart_items(cart):
    """Expand cart mapping into priced lines with verified product records."""
    result = []
    for key, quantity in cart.items():
        product = get_product(int(key))
        if product and int(quantity) > 0:
            result.append(
                {
                    "product": product,
                    "quantity": int(quantity),
                    "subtotal": product["price"] * int(quantity),
                }
            )
    return result


def get_total(items):
    """Sum item subtotals (BP-02)."""
    return sum(item["subtotal"] for item in items)
